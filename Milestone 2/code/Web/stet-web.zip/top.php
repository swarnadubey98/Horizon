<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="Generator" content="EditPlus�">
  <meta name="Author" content="">
  <meta name="Keywords" content="">
  <meta name="Description" content="">
  <link rel="stylesheet" href="style/main.css">
  <link href="style/bootstrap.css" type="text/css" rel="stylesheet" />	<title>

</title><meta charset="utf-8" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>STET</title>
 </head>
 <body>
	<div class="container-fluid">
	<!---          HEADER-START          ------->
	<div class="top_banner">
    <div class="container in_banner">
        <div class=" logo col-md-3 col-sm-3 col-xs-12">
            <img id="ctl00_TopLinks1_imgLogoLeft" class="img-responsive" src="https://ctet.nic.in/CMS/Handler/FileHandler.ashx?i=BasicInformation&amp;ii=0" style="border-width:0px;" />
        </div>
        <div class="banner_text col-md-6 col-sm-6 col-xs-12">
            <h1>
                <span id="ctl00_TopLinks1_lblHeader">Sikkim Teacher Eligibility Test (STET)</span>
            </h1>
            <h2>
                <span id="ctl00_TopLinks1_lblSubHeader">SIKKIM BOARD OF SECONDARY EDUCATION</span>
            </h2>
        </div>
        <div class=" logo col-md-3 col-sm-3 col-xs-12">
             <img id="ctl00_TopLinks1_imgLogoRight" class="img-responsive pull-right" src="https://ctet.nic.in/CMS/Handler/FileHandler.ashx?i=BasicInformation&amp;ii=1" style="border-width:0px;" />
        </div>
    </div>
</div>

    <nav class="navbar navbar-inverse" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
              
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" >            
            <ul id="ctl00_TopLinks_BLinks" class="nav navbar-nav navbar-left" style="display:inline;"><li> <a target='_self' href='index.html'>HOME</a></li><li> <a target='_self' href='https://ctet.nic.in/CMS/Handler/FileHandler.ashx?i=File&ii=171&iii=Y'>CONTACT US</a></li></ul>

        </div>
    </div>
    </nav>
		<!------          Header   End             -------------------->	
 </body>
</html>
