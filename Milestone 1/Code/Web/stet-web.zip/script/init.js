// Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyBBUYBTDIbcbDjx0PYJBQCnC8CJtoUK4oI",
    authDomain: "stet-a37a6.firebaseapp.com",
    databaseURL: "https://stet-a37a6.firebaseio.com",
    projectId: "stet-a37a6",
    storageBucket: "stet-a37a6.appspot.com",
    messagingSenderId: "574384002123",
    appId: "1:574384002123:web:20013b3a8dd20ee8d929ce",
    measurementId: "G-4EFBT9XG9Y"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();